export class Pokemon {
  constructor(id, nombre, tipo, nivel, hp) {
    this.id = id;
    this.nombre = nombre;
    this.tipo = tipo;
    this.nivel = nivel;
    this.hp = hp;
  }
}
